Drupal module: Notifications
============================

This is a proof of concept Notifications module built from scrach for Drupal 7

http://drupal.org/project/notifications
